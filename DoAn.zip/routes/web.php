<?php
use App\Models\User;
use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;
use Illuminate\Support\Facades\Auth;    
//Đây là của P thêm   
use Illuminate\Http\Request;


// Import các controller
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\SinhVienController;
use App\Http\Controllers\GiangVienController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\PhongThiController;
use App\Http\Controllers\LichThiController;
use App\Http\Controllers\PhanCongGiamThiController;
use App\Models\GiangVien;
use App\Models\LichThi;
use App\Models\SinhVien;

// Trang chủ
Route::get('/', function () {
    return Inertia::render('Welcome', [
        'canLogin' => Route::has('login'),
        'canRegister' => Route::has('register'),
        'laravelVersion' => Application::VERSION,
        'phpVersion' => PHP_VERSION,
    ]);
});

// Dashboard — tự động chuyển trang Vue theo vai trò
Route::get('/dashboard', function () {
    /** @var User|null $user */
    $user = Auth::user();

    if (!$user) {
        return redirect()->route('login');
    }

    switch ($user->role) {
        case 'Admin':
            return Inertia::render('Admin/Index', ['user' => $user]);
        case 'GiangVien':
            return Inertia::render('GiangVien/Index', ['user' => $user]);
        case 'SinhVien':
            return Inertia::render('SinhVien/Index', ['user' => $user]);
        default:
            return Inertia::render('SinhVien/Index', ['user' => $user]);
    }
})->middleware(['auth', 'verified'])->name('dashboard');

//Logout route (P)
Route::post('/logout', function (Request $request) {
    Auth::logout(); // Đăng xuất user

    // Xóa session & regenerate token
    $request->session()->invalidate();
    $request->session()->regenerateToken();

    // Quay về trang login
    return redirect()->route('login');
})->name('logout');

Route::resource('sinhviens', SinhVienController::class)->middleware(['auth', 'verified']);
Route::resource('giangviens', GiangVienController::class)->middleware(['auth', 'verified']);
Route::resource('admin', AdminController::class)->middleware(['auth', 'verified']);

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';

// Các route danh sách
Route::get('/sinhviens', [SinhVienController::class, 'index']);
Route::get('/giangviens', [GiangVienController::class, 'index']);
Route::get('/phongthis', [PhongThiController::class, 'index']);
Route::get('/lichthis', [LichThiController::class, 'index']);
Route::get('/phanconggiamthis', [PhanCongGiamThiController::class, 'index']);

// ✅ Nhóm các route cho sinh viên
Route::prefix('sinhvien')->group(function () {
    // Route cần đăng nhập (nếu bạn dùng Sanctum)
    Route::middleware('auth:sanctum')->get('/thongtin', [SinhVienController::class, 'info']);

    // Route công khai (test tạm thời)
    Route::get('/diemdanh', [SinhVienController::class, 'attendance']);
    Route::get('/lichthi', [SinhVienController::class, 'examSchedule']);
});




Route::prefix('giangvien')->group(function () {
    Route::get('/doimatkhau', [GiangVienController::class, 'showDoiMatKhau'])->name('giangvien.doimatkhau');
    Route::post('/doimatkhau', [GiangVienController::class, 'updateMatKhau'])->name('giangvien.updateMatKhau');
});

// API cho giảng viên
Route::middleware('auth')->group(function () {
    Route::get('/giangvien/thongtin', [GiangVienController::class, 'thongTin']);
    Route::get('/giangvien/lichgac', [GiangVienController::class, 'lichGac']);
    Route::get('/giangvien/ketqua', [GiangVienController::class, 'ketQua']);
    
    // Xác nhận/từ chối lịch gác thi
    Route::post('/giangvien/phan-cong/{id}/confirm', [GiangVienController::class, 'confirmAssignment']);
    Route::post('/giangvien/phan-cong/{id}/reject', [GiangVienController::class, 'rejectAssignment']);
    Route::get('/giangvien/phan-cong/pending', [GiangVienController::class, 'getPendingAssignments']);
    
    // Điểm danh API
    Route::get('/giangvien/sinh-vien/{mssv}', [GiangVienController::class, 'getSinhVienByMssv']);
    Route::post('/giangvien/diem-danh', [GiangVienController::class, 'diemDanh']);
    Route::get('/giangvien/lich-thi/{id}/sinh-vien', [GiangVienController::class, 'getDanhSachSinhVien']);
});


Route::middleware('auth')->group(function () {
    Route::get('/admin/lecturers', [AdminController::class, 'lecturers']);
    Route::get('/admin/students',   [AdminController::class, 'students']);
    Route::get('/admin/schedules',  [AdminController::class, 'schedules']);
    Route::get('/admin/attendance', [AdminController::class, 'attendance']);
});

// API nhẹ cho trang Admin
Route::get('/admin/lecturers', [AdminController::class, 'lecturers'])->middleware(['auth','verified']);
Route::get('/admin/students',   [AdminController::class, 'students'])->middleware(['auth','verified']);
Route::get('/admin/schedules',  [AdminController::class, 'schedules'])->middleware(['auth','verified']);
Route::get('/admin/attendance', [AdminController::class, 'attendance'])->middleware(['auth','verified']);

Route::get('/test/admin-schedules-sample', function () {
    return response()->json([
        ['id'=>1,'lecturerCode'=>'gv1@example.com','subjectCode'=>'MT101','subjectName'=>'Cơ sở dữ liệu','date'=>'2025-11-01','start'=>'08:00','end'=>'10:00','note'=>'','room'=>'C103'],
    ]);
});

Route::get('/lecturers', [AdminController::class, 'getLecturers']);
Route::get('/students', [AdminController::class, 'getStudents']);
Route::get('/schedules', [AdminController::class, 'getSchedules']); //lich thi phan cong

// Thêm / Sửa sinh viên (dùng bởi frontend Admin)
Route::post('/students/add', [AdminController::class, 'addStudent'])->middleware(['auth','verified']);
Route::put('/students/update/{id}', [AdminController::class, 'updateStudent'])->middleware(['auth','verified']);

// Đổi mật khẩu cho Admin
Route::get('/admin/change-password', [AdminController::class, 'showChangePassword'])->middleware(['auth','verified'])->name('admin.change-password');
Route::post('/admin/change-password', [AdminController::class, 'updatePassword'])->middleware(['auth','verified'])->name('admin.update-password');





//chuc năng thêm xoa sua lịch thi
Route::post('/schedules/add', [LichThiController::class, 'addSchedule']);
Route::put('/schedules/update/{id}', [LichThiController::class, 'updateSchedule']);
Route::delete('/schedules/delete/{id}', [LichThiController::class, 'deleteSchedule']);

// Import/Export lịch thi từ Excel
Route::get('/schedules/template/download', [LichThiController::class, 'downloadTemplate']);
Route::post('/schedules/import', [LichThiController::class, 'importSchedules'])->middleware(['auth','verified']);


//chức năng thêm xóa sửa trong giảng viên
Route::post('/lecturers/add', [GiangVienController::class, 'addLecturer']);
Route::delete('/lecturers/delete/{id}', [GiangVienController::class, 'deleteLecturer']);
Route::put('/lecturers/update/{id}', [GiangVienController::class, 'updateLecturer']);

//chức năng thêm xóa sửa trong sinh viên
Route::put('/sinhviens/update/{id}', [SinhVienController::class, 'updateStudent']);
Route::delete('/students/delete/{id}', [SinhVienController::class, 'deleteStudent'])->middleware(['auth','verified']);
Route::post('/students/delete-all', [SinhVienController::class, 'deleteAllStudents'])->middleware(['auth','verified']);

